(function () {
  "use strict";

  $(function () {
    $(".menu-container").load("menu.html");
  });
})();